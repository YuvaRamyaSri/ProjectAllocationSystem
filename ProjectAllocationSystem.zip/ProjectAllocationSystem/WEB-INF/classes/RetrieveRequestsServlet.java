import java.util.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.*;

public class RetrieveRequestsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/studentdb?useSSL=false";
        String username = "root";
        String password = "1234";

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, username, password);

            

            String query = "SELECT * FROM complaints";
            PreparedStatement statement = con.prepareStatement(query);
            
            ResultSet resultSet = statement.executeQuery();

            out.println("<style>");
            out.println("table {");
            out.println("    width: 80%;");
            out.println("    margin: 0 auto;"); // Align the table at the center
            out.println("    border-collapse: collapse;");
            out.println("}");
            out.println("th, td {");
            out.println("    border: 1px solid black;");
            out.println("    padding: 8px;");
            out.println("}");
            out.println("</style>");

            out.println("<table>");
            out.println("<tr><th>Student Name</th><th>Branch</th><th>Project Name</th><th>Project Description</th></tr>");
            while (resultSet.next()) {
                out.println("<tr>");
                out.println("<td>" + resultSet.getString(1) + "</td>");
                out.println("<td>" + resultSet.getString(2) + "</td>");
                out.println("<td>" + resultSet.getString(3) + "</td>");
                out.println("<td>" + resultSet.getString(4) + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            resultSet.close();
            statement.close();
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            out.println("Error: " + e.getMessage());
        }
    }
}
