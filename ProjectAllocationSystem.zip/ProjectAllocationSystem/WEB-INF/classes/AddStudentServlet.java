import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class AddStudentServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String studentId = request.getParameter("id");
        String studentName = request.getParameter("stname");
        String studentEmail = request.getParameter("stemail");
        String studentPhone = request.getParameter("stphone");
        String studentPassword = request.getParameter("stpass");
        String studentCourse = request.getParameter("stcourse");


        // Create database connection
        try {
            Class.forName(com.mysql.jdbc.Driver);
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb?useSSL=false","root","Devi@ramya111");
            // Prepare SQL statement
            String sql = "INSERT INTO students (sid, sname, semail, sphone, spassword, scourse) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);

            // Set parameter values
            statement.setString(1, studentId);
            statement.setString(2, studentName);
            statement.setString(3, studentEmail);
            statement.setString(4, studentPhone);
            statement.setString(5, studentPassword);
            statement.setString(6, studentCourse);

            // Execute the SQL statement
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                // Data inserted successfully
                response.sendRedirect("login.html");
            } else {
                // Failed to insert data
                response.sendRedirect("error.html");
            }
        } catch (SQLException e) {
            // Handle database errors
            e.printStackTrace();
            response.sendRedirect("error.html");
        }
    }
}