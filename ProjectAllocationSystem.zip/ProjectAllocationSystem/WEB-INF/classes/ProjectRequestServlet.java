import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProjectRequestServlet extends HttpServlet {


    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String studentName = request.getParameter("StudentName");
        String branch = request.getParameter("Branch");
        String projectName = request.getParameter("projectName");
        String projectDescription = request.getParameter("projectDescription");

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Open a connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb?useSSL=false", "root@localhost", "Devi@ramya111");

            // Prepare SQL statement
            String sql = "INSERT INTO projects (student_name, branch, project_name, project_description) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentName);
            stmt.setString(2, branch);
            stmt.setString(3, projectName);
            stmt.setString(4, projectDescription);

            // Execute the query
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                out.println("<h3>Project request submitted successfully!</h3>");
            } else {
                out.println("<h3>Failed to submit the project request. Please try again.</h3>");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            out.println("<h3>Unable to load JDBC driver. Please check your dependencies.</h3>");
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<h3>An error occurred while processing the request. Please try again later.</h3>");
        } finally {
            // Clean up resources
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            out.close();
        }
    }
}
